# VITALIS — initial website prototype

Responsive Russian-language medical/science landing page, built with plain HTML/CSS/JS and no external libraries.

## Add your falling-pills video
1. Put your video file in `assets/` and name it `pills.mp4`.
2. The page looks for `/assets/pills.mp4` and uses the scroll position to scrub the video timeline forward/backward. The video is muted and paused on the current frame. If no video is present, a CSS capsule animation is shown as a temporary fallback.
3. The Google Drive link supplied in chat could not be downloaded in this environment. Please upload the MP4 directly or change Drive General access to “Anyone with the link” and provide a direct-download link.

## Current limitations
- This is a frontend prototype. No real AI model is connected; the AI assistant panel clearly says it is a demo.
- No login, database, subscriptions, payments, diagnosis, or medical records are active.
- GitHub connection currently exposes no repositories, and the available GitHub tools do not create a new repository.
- Cloudflare account has no `workers.dev` subdomain enabled yet. Publishing must wait until that is enabled or a Pages deployment path is available.
- Supabase organization exists but has no projects. Creating a project requires selecting the organization and confirming cost/region.

## Run locally
Open `index.html` in a browser. For video seeking, use a local static server rather than `file://` if possible.
